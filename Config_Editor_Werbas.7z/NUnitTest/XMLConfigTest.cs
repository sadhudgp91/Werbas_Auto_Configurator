using NUnit.Framework;
using System.Collections.Specialized;
using System.Xml;
using System.Xml.Schema;

namespace NUnitTest
{
    public class Tests
    {
        private object chkIgnoreWhiteSpace;

        [Test]
              
            public void Test_AddXML()
            {
                Test_AddXML xml = new Test_AddXML();
               // double res = xml.add();
               // Assert.AreEqual(res, 20);
            }
        
            public void Test_UpdateXML()
            {
            Test_UpdateXML xml = new Test_UpdateXML();
            //double res = xml.update(10, 10);
                //Assert.AreEqual(res, 0);
            }
            
            public void Test_EditXML()
            {
            Test_EditXML xml = new Test_EditXML();
            //double res = xml.edit(10, 5);
               // Assert.AreEqual(res, 2);
            }
          
            public void Test_DeleteXML()
            {
            Test_DeleteXML xml = new Test_DeleteXML();
            //double res = xml.delete(10, 10);
                //Assert.AreEqual(res, 100);
            }


        [Test]
        public void pseudo_test(string path)
        {
            string xml = "Your xml string here";
            XmlDocument doc = new XmlDocument();
            doc.LoadXml(xml);
            path = "/doc/element1[@id='key1']/element2[. = 'value2']";
            Assert.IsTrue(doc.SelectSingleNode(path) != null);
        }

        
            void CheckXml()
            {
                string _xmlFile = "this.xml";
                string _xsdFile = "schema.xsd";
                StringCollection _xmlErrors = new StringCollection();

                XmlReader reader = null;
                XmlReaderSettings settings = new XmlReaderSettings();
                settings.ValidationEventHandler += new ValidationEventHandler(this.ValidationEventHandler);
                settings.ValidationType = ValidationType.Schema;
               // settings.IgnoreComments = chkIgnoreComments.Checked;
              //  settings.IgnoreProcessingInstructions = chkIgnoreProcessingInstructions.Checked;
               // settings.IgnoreWhitespace = chkIgnoreWhiteSpace.Checked;
                settings.Schemas.Add(null, XmlReader.Create(_xsdFile));
                reader = XmlReader.Create(_xmlFile, settings);
                while (reader.Read())
                {
                }
                reader.Close();
                Assert.AreEqual(_xmlErrors.Count, 0);
            }

            void ValidationEventHandler(object sender, ValidationEventArgs args)
            {
               // _xmlErrors.Add("<" + args.Severity + "> " + args.Message);
            }

       
    }

    internal class chkIgnoreProcessingInstructions
    {
    }

    internal class chkIgnoreComments
    {
    }

    internal class Test_UpdateXML
    {

    }

    internal class Test_EditXML
    {
        
    }


    internal class Test_DeleteXML
    {
    }

    internal class Test_AddXML
    {

    }
}