﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TextEditor.Model; 
using System.ComponentModel;
using System.Windows;
using System.Collections.ObjectModel;
using System.IO;
using System.Windows.Documents;
using System.Windows.Media;
using System.Windows.Data;
using Microsoft.Win32;
using System.Windows.Controls;
using System.Windows.Input;
using ICSharpCode.AvalonEdit;
using ICSharpCode.AvalonEdit.Highlighting;

namespace TextEditor.ViewModel
{   

    class MainWindowViewModel : DependencyObject, INotifyPropertyChanged
    {
        #region Relay Commands : Save command etc.


        private ICommand _SaveCmd { get; set; }
        public ICommand SaveCmd
        {
            get { return _SaveCmd; }
            set
            {
                if (PropertyChanged != null)
                {
                    _SaveCmd = value;
                    PropertyChanged(this,
                        new PropertyChangedEventArgs("SaveCmd"));
                }
            }
        }

        public ICommand SaveAsCmd
        {
            get{ return new RelayCommand(param => SaveDocumentAs(), true); }
        }

        public ICommand NewDocCmd
        {
            get{ return new RelayCommand(param => NewDocument(), true); }
        }

        public ICommand OpenDocCmd
        {
            get{ return new RelayCommand(param => OpenDocument(), true); }
        }
        #endregion

     
        private string _status { get; set; }
        public string status
        {
            get { return _status; }
            set
            {
                if (PropertyChanged != null)
                {
                    _status = value;
                    PropertyChanged(this,
                        new PropertyChangedEventArgs("status"));
                }
            }
        }

      
        public TextAreaModel _selectedTab { get; set; }
        public TextAreaModel selectedTab
        {
            get { return _selectedTab; }
            set
            {
                if (PropertyChanged != null)
                {                  
                    _selectedTab = value;
                    if(showLineNumber != selectedTab.content.ShowLineNumbers)
                        showLineNumber = selectedTab.content.ShowLineNumbers;
                    PropertyChanged(this,
                        new PropertyChangedEventArgs("selectedTab"));
                }
            }
        }

        public bool showLineNumber
        {
            get
            {
                return selectedTab.content.ShowLineNumbers;
            }
            set
            {
                if (PropertyChanged != null)
                {
                    selectedTab.content.ShowLineNumbers = value;
                    status = Properties.Resources.lineNumsToggled;
                    PropertyChanged(this,
                        new PropertyChangedEventArgs("showLineNumber"));
                }              
            }
        }
        public string _currentFile { get; set; }
        public ObservableCollection<TextAreaModel> tabs { get; set; } 
        public MainWindowViewModel()
        {
            tabs = new ObservableCollection<TextAreaModel>()
            {
                new TextAreaModel { header = Properties.Resources.newDocument, content = CreateXMLConfigDocument() }
            };
            selectedTab = tabs.FirstOrDefault();
            SaveCmd = new RelayCommand(param => SaveDocument(), false);
        }

        private ICSharpCode.AvalonEdit.TextEditor CreateXMLConfigDocument()
        {
            var content = new ICSharpCode.AvalonEdit.TextEditor();
            content.Name = "display";
            return content;
        }

        public void NewDocument()
        { 
            _currentFile = null;
            selectedTab = new TextAreaModel()
            {
                header = Properties.Resources.newDocument,
                content = CreateXMLConfigDocument()
            };
            tabs.Add(selectedTab);
            status = Properties.Resources.documentCreated;
        }

        public void OpenDocument()
        {
            OpenFileDialog fileDialog = new OpenFileDialog();

            if (fileDialog.ShowDialog() == true)
            {
                _currentFile = fileDialog.FileName;
                selectedTab = new TextAreaModel()
                {
                    header = fileDialog.FileName.Split('\\').Last(), 
                    content = CreateXMLConfigDocument()
                };

                selectedTab.content.Load(_currentFile);
                tabs.Add(selectedTab);
                CanSaveDocument();
                status = Properties.Resources.documentLoaded;
            }
        }

        public void SaveDocument()
        {
            if (string.IsNullOrEmpty(_currentFile))
                SaveDocumentAs();
            else
            {
                selectedTab.content.Save(_currentFile);
                status = Properties.Resources.documentSaved;
            }
        }

        public void SaveDocumentAs()
        {

            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "Config files (*.config)|*.config|XML files (*.xml)|*.xml|All files (*.*)|*.*";
            saveFileDialog.FilterIndex = 2;
            saveFileDialog.RestoreDirectory = true;
            saveFileDialog.OverwritePrompt = true;
            saveFileDialog.AddExtension = true;

            if (saveFileDialog.ShowDialog() == true)
            {
                _currentFile = saveFileDialog.FileName;
                SaveDocument();
                CanSaveDocument();
            }
        }

   
        public void CanSaveDocument()
        {
            SaveCmd = new RelayCommand(param => SaveDocument(), !string.IsNullOrEmpty(_currentFile));
        }

        public event PropertyChangedEventHandler PropertyChanged;
    }

    public class RelayCommand : ICommand
    {
        private Action<Object> _action;
        private bool _canExecute;
        public RelayCommand(Action<Object> action, bool canExecute)
        {
            _action = action;
            _canExecute = canExecute;
        }

        public bool CanExecute(object parameter)
        {
            return _canExecute;
        }

        public event EventHandler CanExecuteChanged;

        public void Execute(object parameter)
        {
            _action(parameter);
        }
    }
}