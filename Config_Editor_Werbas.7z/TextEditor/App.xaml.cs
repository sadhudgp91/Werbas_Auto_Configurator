﻿using System;
using System.IO;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace TextEditor
{
    public partial class App : Application
    {
        public App()
        {
        }
    }
}